<h1>Limpieza de Tapizados</h1>
<p> Es un emprendimiento, pero se me ocurrio hacerlo para el proyecto de coderhouse</p>
<h2>Teecnologias usadas</h2>
<ul>
<li>Html5</li>
<li>CSS3</li>
<li>Bootstrap</li>
<li>SASS</li>
</ul>